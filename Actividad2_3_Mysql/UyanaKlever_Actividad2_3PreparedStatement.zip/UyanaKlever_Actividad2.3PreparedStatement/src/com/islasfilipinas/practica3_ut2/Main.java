package com.islasfilipinas.practica3_ut2;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
public class Main {
	public static void main(String[] args) {
		/* Calendar fecha = new GregorianCalendar();
		int a�o = fecha.get(Calendar.YEAR);
        int mes = fecha.get(Calendar.MONTH);
        int dia = fecha.get(Calendar.DAY_OF_MONTH);
        String Fecha =a�o + "-" + (mes+1) + "-" + dia;
        System.out.println(F);*/
        
		MySQL nuevo = new MySQL();
		//nuevo.inserttablaEmple_2(); //PreparedStatement
		//nuevo.inserttablaEmple();   //CreateStatement
		nuevo.SeleciontablaEmple();
		//nuevo.seleciontablaEmple_Dep();
		
	}

}
